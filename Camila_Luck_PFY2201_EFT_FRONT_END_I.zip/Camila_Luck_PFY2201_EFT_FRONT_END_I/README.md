

---

## Estructura del proyecto


```
.
├── README.md
├── version-js/                  # Parte 1: HTML + CSS + JavaScript + Bootstrap 5
│   ├── index.html               # Estructura semántica (header, nav, main, section, footer)
│   ├── css/styles.css           # Estilos propios, Flexbox y CSS Grid
│   ├── js/datos.js              # Objeto "tienda" con la información de los videojuegos
│   ├── js/app.js                # Tarjetas dinámicas, filtros y validación del formulario
│   └── img/                     # Portadas de los videojuegos
│
└── version-react/               # Parte 2: la misma tienda dividida en componentes React
    ├── index.html
    ├── package.json
    ├── vite.config.js
    ├── public/
    │   ├── data/videojuegos.json   # Catálogo que se carga con fetch al iniciar
    │   └── img/                    # Portadas de los videojuegos
    └── src/
        ├── main.jsx                # Punto de entrada (importa Bootstrap y monta <App />)
        ├── App.jsx                 # Componente principal: maneja el state
        ├── App.css                 # Estilos propios
        ├── utils/
        │   ├── validaciones.js     # Funciones de validación reutilizables
        │   └── formato.js          # Formato de precios en CLP
        └── components/
            ├── Navbar.jsx              # Barra de navegación
            ├── Hero.jsx                # Sección de bienvenida
            ├── FiltroCategorias.jsx    # Botones de filtro por categoría
            ├── ListaVideojuegos.jsx    # Grilla con la lista de juegos
            ├── TarjetaVideojuego.jsx   # Tarjeta reutilizable de un juego
            ├── FormularioVideojuego.jsx# Agregar juegos al catálogo
            ├── FormularioContacto.jsx  # Contacto con validación
            └── Footer.jsx              # Pie de página
```

---

## Requisitos

- Un navegador moderno (Chrome, Firefox, Edge o Safari).
- Para la versión React: **Node.js 20.19 o superior** (incluye npm). Se descarga desde https://nodejs.org
- Git (opcional, para clonar el repositorio).

---

## Instalación y ejecución

### 1. Obtener el proyecto


```bash
git clone <enlace-del-repositorio>
```

Luego abre la carpeta del proyecto en VS Code.

### 2. Versión HTML + CSS + JavaScript

No necesita instalación. Hay dos formas de abrirla:

- **Opción A:** abrir el archivo `version-js/index.html` con doble clic.
- **Opción B (recomendada):** en VS Code, clic derecho sobre `version-js/index.html` → **Open with Live Server**.

> Bootstrap 5 se carga desde CDN, así que se necesita conexión a internet.

### 3. Versión React

```bash
cd version-react
npm install      # instala React, Bootstrap y Vite
npm run dev      # inicia el servidor de desarrollo
```

Luego abrir en el navegador la dirección que aparece en la terminal (normalmente http://localhost:5173).

Para generar la versión de producción:

```bash
npm run build    # crea la carpeta dist/
npm run preview  # sirve la versión de producción para probarla
```

---

## Uso del sitio

| Funcionalidad | Cómo usarla |
|---|---|
| **Navegar** | Usa la barra superior (Inicio, Catálogo, Contacto). En celulares se abre con el botón ☰. |
| **Ver el catálogo** | Cada tarjeta muestra imagen, nombre, categoría, descripción y precio. |
| **Filtrar** | Haz clic en una categoría (Acción, RPG, Deportes…). "Todas" muestra el catálogo completo. El contador indica cuántos juegos se ven. |
| **Contacto** | Completa nombre, email y mensaje y presiona *Enviar*. Si falta un dato o está mal escrito, el campo se marca en rojo con el error. |
| **Agregar juego** *(solo React)* | En la sección "Agregar videojuego" completa el formulario. El juego aparece al instante en el catálogo y se actualiza el contador de la barra de navegación. |
| **Eliminar juego** *(solo React)* | Botón *Eliminar* en cada tarjeta (pide confirmación). |

### Reglas de validación del formulario de contacto

- **Nombre:** obligatorio, mínimo 3 caracteres, solo letras y espacios.
- **Email:** obligatorio y con formato válido (`nombre@dominio.cl`).
- **Mensaje:** obligatorio, mínimo 10 caracteres.

---

## Tecnologías y cómo se aplicaron

### HTML5 y CSS3
- Etiquetas semánticas: `<header>`, `<nav>`, `<main>`, `<section>`, `<article>` (cada tarjeta) y `<footer>`.
- **CSS Grid** para la grilla de tarjetas (`repeat(auto-fill, minmax(260px, 1fr))`), que se adapta sola al ancho de la pantalla.
- **Flexbox** para el hero, los botones de filtro, el cuerpo de las tarjetas y el pie de página.
- Variables CSS, efecto *hover* en las tarjetas y media queries para celulares.

### Bootstrap 5
- Componentes: **Navbar** responsiva con menú hamburguesa, **Cards**, **Badges**, **Buttons**, **Forms** con estados `is-invalid` / `invalid-feedback`, **Alerts**.
- Sistema de grillas (`container`, `row`, `col-12 col-md-8 col-lg-6`) y utilidades de espaciado.

### JavaScript (version-js)
- `datos.js` define el objeto **`tienda`** con el arreglo `videojuegos` (nombre, categoría, precio, descripción e imagen).
- `app.js` recorre el objeto y **crea las tarjetas con el DOM** (`createElement`, `appendChild`, `innerHTML`).
- Los botones de filtro también se generan a partir de las categorías que existen en el objeto (`Set`).
- El formulario se valida con expresiones regulares en el evento `submit` (`preventDefault`) y muestra los errores bajo cada campo.

### React (version-react)
- **Componentes:** la interfaz está dividida en 8 componentes, cada uno en su propio archivo.
- **State (`useState`) en `App.jsx`:** la lista de videojuegos, la categoría seleccionada, el estado de carga y los errores.
- **Carga desde archivo (`useEffect` + `fetch`):** los videojuegos se leen de `public/data/videojuegos.json` al iniciar.
- **Props:** `App` envía a cada componente los datos y las funciones que necesita:
  - `FiltroCategorias` recibe `categorias`, `seleccionada` y `onSeleccionar` → al hacer clic actualiza el state de `App`, y `ListaVideojuegos` se vuelve a dibujar con la lista filtrada.
  - `ListaVideojuegos` → `TarjetaVideojuego` recibe `juego` y `onEliminar`.
  - `FormularioVideojuego` recibe `onAgregar`; `Navbar` recibe `totalJuegos`, que cambia al agregar o eliminar.
- **Componentes reutilizables:** `TarjetaVideojuego` se usa para cada juego; las validaciones están en `utils/validaciones.js` y las usan los dos formularios.

---

## Pruebas realizadas

- Filtrado por cada categoría y por "Todas" (el contador coincide con las tarjetas visibles).
- Formulario de contacto: campos vacíos, email inválido, nombre con números, mensaje corto y envío correcto.
- Agregar y eliminar videojuegos (React): la lista, el contador y la barra de navegación se actualizan.
- Diseño responsivo probado en 390 px (celular), 768 px (tablet) y 1280 px (escritorio), sin desplazamiento horizontal.
- Navegadores: Google Chrome, Mozilla Firefox y Microsoft Edge.

---

## Capturas

**Escritorio**

![Vista de escritorio](capturas/escritorio.png)

**Celular**

<img src="capturas/celular.png" alt="Vista en celular" width="300">

---

## Licencia

Proyecto académico desarrollado para Duoc UC. Las portadas de los videojuegos son ilustraciones creadas para este proyecto; los juegos son ficticios.
