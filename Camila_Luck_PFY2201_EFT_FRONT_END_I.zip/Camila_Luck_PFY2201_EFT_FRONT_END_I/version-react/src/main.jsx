import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

// Bootstrap 5: estilos y JS (el JS es necesario para el menú hamburguesa)
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap"; // JS de Bootstrap (activa data-bs-toggle)

// Estilos personalizados
import "./App.css";

import App from "./App.jsx";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <App />
  </StrictMode>
);
