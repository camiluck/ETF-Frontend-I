import { useEffect, useState } from "react";

import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import FiltroCategorias from "./components/FiltroCategorias.jsx";
import ListaVideojuegos from "./components/ListaVideojuegos.jsx";
import FormularioVideojuego from "./components/FormularioVideojuego.jsx";
import FormularioContacto from "./components/FormularioContacto.jsx";
import Footer from "./components/Footer.jsx";

// Ruta del archivo JSON con los videojuegos (carpeta public/data)
const URL_DATOS = `${import.meta.env.BASE_URL}data/videojuegos.json`;

// Categorías base de la tienda (se combinan con las que vengan en los datos)
const CATEGORIAS_BASE = ["Acción", "Aventura", "Carreras", "Deportes", "Estrategia", "RPG"];

function App() {
  // ----- STATE -----
  const [videojuegos, setVideojuegos] = useState([]); // lista de videojuegos
  const [categoriaSeleccionada, setCategoriaSeleccionada] = useState("Todas");
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");

  // Carga los videojuegos desde el archivo JSON al iniciar la aplicación
  useEffect(() => {
    fetch(URL_DATOS)
      .then((respuesta) => {
        if (!respuesta.ok) throw new Error("No se pudo cargar el catálogo.");
        return respuesta.json();
      })
      .then((datos) => setVideojuegos(datos))
      .catch((err) => setError(err.message))
      .finally(() => setCargando(false));
  }, []);

  // ----- Funciones que modifican el state (se pasan como props) -----
  const agregarVideojuego = (nuevo) => {
    const nuevoId = videojuegos.length > 0 ? Math.max(...videojuegos.map((j) => j.id)) + 1 : 1;
    setVideojuegos([...videojuegos, { ...nuevo, id: nuevoId }]);
  };

  const eliminarVideojuego = (id) => {
    setVideojuegos(videojuegos.filter((juego) => juego.id !== id));
  };

  // ----- Datos derivados del state -----
  const categorias = [...new Set([...CATEGORIAS_BASE, ...videojuegos.map((j) => j.categoria)])].sort();

  const videojuegosFiltrados =
    categoriaSeleccionada === "Todas"
      ? videojuegos
      : videojuegos.filter((juego) => juego.categoria === categoriaSeleccionada);

  return (
    <>
      <Navbar nombreTienda="GameZone" totalJuegos={videojuegos.length} />

      <main>
        <Hero />

        <section id="catalogo" className="py-5">
          <div className="container">
            <h2 className="text-center mb-4">Catálogo de videojuegos</h2>

            <FiltroCategorias
              categorias={["Todas", ...categorias]}
              seleccionada={categoriaSeleccionada}
              onSeleccionar={setCategoriaSeleccionada}
            />

            {cargando && <p className="text-center">Cargando videojuegos...</p>}
            {error && <div className="alert alert-danger text-center">{error}</div>}

            {!cargando && !error && (
              <>
                <p className="text-center text-muted">
                  Mostrando {videojuegosFiltrados.length} de {videojuegos.length} videojuegos
                </p>
                <ListaVideojuegos videojuegos={videojuegosFiltrados} onEliminar={eliminarVideojuego} />
              </>
            )}
          </div>
        </section>

        <section id="administrar" className="py-5 bg-body-tertiary">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-md-10 col-lg-8">
                <h2 className="text-center mb-4">Agregar videojuego</h2>
                <FormularioVideojuego categorias={categorias} onAgregar={agregarVideojuego} />
              </div>
            </div>
          </div>
        </section>

        <section id="contacto" className="py-5">
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-12 col-md-8 col-lg-6">
                <h2 className="text-center mb-4">Contáctanos</h2>
                <FormularioContacto />
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer nombreTienda="GameZone" />
    </>
  );
}

export default App;
