// Sección de bienvenida de la página principal.
function Hero() {
  return (
    <section id="inicio" className="hero text-white">
      <div className="container hero-contenido">
        <h1 className="display-5 fw-bold">Los mejores videojuegos, en un solo lugar</h1>
        <p className="lead">Encuentra tu próximo juego favorito y filtra por la categoría que más te guste.</p>
        <a href="#catalogo" className="btn btn-warning btn-lg">
          Ver catálogo
        </a>
      </div>
    </section>
  );
}

export default Hero;
