import { Collapse } from "bootstrap";

// Barra de navegación (componente Navbar de Bootstrap 5).
// Props: nombreTienda (texto de la marca) y totalJuegos (cantidad en el catálogo).
function Navbar({ nombreTienda, totalJuegos }) {
  const enlaces = [
    { href: "#inicio", texto: "Inicio" },
    { href: "#catalogo", texto: "Catálogo" },
    { href: "#administrar", texto: "Agregar juego" },
    { href: "#contacto", texto: "Contacto" },
  ];

  // En celulares, cierra el menú desplegable al tocar un enlace
  const cerrarMenu = () => {
    const menu = document.getElementById("menuPrincipal");
    if (menu.classList.contains("show")) {
      Collapse.getOrCreateInstance(menu).hide();
    }
  };

  return (
    <header>
      <nav className="navbar navbar-expand-md navbar-dark bg-dark fixed-top shadow" aria-label="Navegación principal">
        <div className="container">
          <a className="navbar-brand fw-bold" href="#inicio">
            🎮 {nombreTienda}
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#menuPrincipal"
            aria-controls="menuPrincipal"
            aria-expanded="false"
            aria-label="Abrir menú"
          >
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="menuPrincipal">
            <ul className="navbar-nav ms-auto align-items-md-center">
              {enlaces.map((enlace) => (
                <li className="nav-item" key={enlace.href}>
                  <a className="nav-link" href={enlace.href} onClick={cerrarMenu}>
                    {enlace.texto}
                  </a>
                </li>
              ))}
              <li className="nav-item ms-md-2">
                <span className="badge text-bg-warning">{totalJuegos} juegos</span>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
}

export default Navbar;
