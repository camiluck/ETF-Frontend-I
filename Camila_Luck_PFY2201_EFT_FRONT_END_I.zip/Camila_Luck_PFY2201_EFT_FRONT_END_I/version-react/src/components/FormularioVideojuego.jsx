import { useState } from "react";
import { validarPrecio, validarRequerido } from "../utils/validaciones.js";

const VALORES_INICIALES = { nombre: "", categoria: "", precio: "", descripcion: "", imagen: "" };

// Formulario para agregar un videojuego nuevo al catálogo.
// Props:
//  - categorias: opciones para el selector
//  - onAgregar: función de App que agrega el juego al state
function FormularioVideojuego({ categorias, onAgregar }) {
  const [valores, setValores] = useState(VALORES_INICIALES);
  const [errores, setErrores] = useState({});
  const [exito, setExito] = useState("");

  const manejarCambio = (e) => {
    const { name, value } = e.target;
    setValores({ ...valores, [name]: value });
  };

  const validar = () => ({
    nombre: validarRequerido(valores.nombre, "El nombre"),
    categoria: validarRequerido(valores.categoria, "La categoría"),
    precio: validarPrecio(valores.precio),
    descripcion: validarRequerido(valores.descripcion, "La descripción"),
  });

  const manejarEnvio = (e) => {
    e.preventDefault();
    const nuevosErrores = validar();
    setErrores(nuevosErrores);

    const hayErrores = Object.values(nuevosErrores).some((mensaje) => mensaje !== "");
    if (hayErrores) {
      setExito("");
      return;
    }

    onAgregar({
      nombre: valores.nombre.trim(),
      categoria: valores.categoria,
      precio: Number(valores.precio),
      descripcion: valores.descripcion.trim(),
      imagen: valores.imagen.trim() || "img/sin-imagen.svg",
    });

    setExito(`"${valores.nombre.trim()}" se agregó al catálogo.`);
    setValores(VALORES_INICIALES);
    setErrores({});
  };

  // Clase de Bootstrap para marcar un campo con error
  const clase = (campo, base = "form-control") => `${base} ${errores[campo] ? "is-invalid" : ""}`;

  return (
    <form onSubmit={manejarEnvio} noValidate className="card card-body shadow-sm">
      <div className="row g-3">
        <div className="col-12 col-md-6">
          <label htmlFor="juegoNombre" className="form-label">Nombre</label>
          <input id="juegoNombre" name="nombre" className={clase("nombre")} value={valores.nombre} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.nombre}</div>
        </div>

        <div className="col-12 col-md-6">
          <label htmlFor="juegoCategoria" className="form-label">Categoría</label>
          <select id="juegoCategoria" name="categoria" className={clase("categoria", "form-select")} value={valores.categoria} onChange={manejarCambio}>
            <option value="">Selecciona una categoría</option>
            {categorias.map((cat) => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
          <div className="invalid-feedback">{errores.categoria}</div>
        </div>

        <div className="col-12 col-md-6">
          <label htmlFor="juegoPrecio" className="form-label">Precio (CLP)</label>
          <input id="juegoPrecio" name="precio" type="number" min="1" className={clase("precio")} value={valores.precio} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.precio}</div>
        </div>

        <div className="col-12 col-md-6">
          <label htmlFor="juegoImagen" className="form-label">URL de imagen (opcional)</label>
          <input id="juegoImagen" name="imagen" className="form-control" placeholder="img/mi-juego.png" value={valores.imagen} onChange={manejarCambio} />
        </div>

        <div className="col-12">
          <label htmlFor="juegoDescripcion" className="form-label">Descripción</label>
          <textarea id="juegoDescripcion" name="descripcion" rows="2" className={clase("descripcion")} value={valores.descripcion} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.descripcion}</div>
        </div>

        <div className="col-12">
          <button type="submit" className="btn btn-success w-100">Agregar al catálogo</button>
        </div>
      </div>

      {exito && <div className="alert alert-success mt-3 mb-0" role="alert">{exito}</div>}
    </form>
  );
}

export default FormularioVideojuego;
