// Botones para filtrar el catálogo por categoría.
// Props:
//  - categorias: lista de categorías a mostrar
//  - seleccionada: categoría activa (viene del state de App)
//  - onSeleccionar: función de App que actualiza el state al hacer clic
function FiltroCategorias({ categorias, seleccionada, onSeleccionar }) {
  return (
    <div className="filtros mb-4" role="group" aria-label="Filtrar por categoría">
      {categorias.map((categoria) => {
        const activa = categoria === seleccionada;
        return (
          <button
            key={categoria}
            type="button"
            className={`btn ${activa ? "btn-dark" : "btn-outline-dark"}`}
            aria-pressed={activa}
            onClick={() => onSeleccionar(categoria)}
          >
            {categoria}
          </button>
        );
      })}
    </div>
  );
}

export default FiltroCategorias;
