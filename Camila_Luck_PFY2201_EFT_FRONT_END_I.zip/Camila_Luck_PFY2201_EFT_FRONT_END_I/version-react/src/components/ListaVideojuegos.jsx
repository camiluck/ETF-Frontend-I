import TarjetaVideojuego from "./TarjetaVideojuego.jsx";

// Muestra la lista de videojuegos en una grilla (CSS Grid).
// Props:
//  - videojuegos: lista ya filtrada que llega desde App
//  - onEliminar: función de App que se pasa a cada tarjeta
function ListaVideojuegos({ videojuegos, onEliminar }) {
  if (videojuegos.length === 0) {
    return <p className="text-center text-muted">No hay videojuegos en esta categoría.</p>;
  }

  return (
    <div className="grilla-juegos">
      {videojuegos.map((juego) => (
        <TarjetaVideojuego key={juego.id} juego={juego} onEliminar={onEliminar} />
      ))}
    </div>
  );
}

export default ListaVideojuegos;
