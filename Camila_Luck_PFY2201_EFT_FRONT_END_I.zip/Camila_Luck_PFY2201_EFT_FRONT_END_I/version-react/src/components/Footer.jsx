// Pie de página. Props: nombreTienda.
function Footer({ nombreTienda }) {
  const anio = new Date().getFullYear();

  return (
    <footer className="bg-dark text-white py-4">
      <div className="container footer-contenido">
        <p className="mb-0">&copy; {anio} {nombreTienda}. Todos los derechos reservados.</p>
        <nav aria-label="Enlaces del pie de página">
          <a href="#inicio" className="link-light me-3">Inicio</a>
          <a href="#catalogo" className="link-light me-3">Catálogo</a>
          <a href="#contacto" className="link-light">Contacto</a>
        </nav>
      </div>
    </footer>
  );
}

export default Footer;
