import { formatearPrecio } from "../utils/formato.js";

// Tarjeta (Card de Bootstrap) reutilizable para un videojuego.
// Props:
//  - juego: objeto con nombre, categoria, precio, descripcion e imagen
//  - onEliminar: función que recibe el id del juego a eliminar
function TarjetaVideojuego({ juego, onEliminar }) {
  const { id, nombre, categoria, precio, descripcion, imagen } = juego;

  const confirmarEliminar = () => {
    if (window.confirm(`¿Eliminar "${nombre}" del catálogo?`)) {
      onEliminar(id);
    }
  };

  return (
    <article className="card tarjeta-juego shadow-sm">
      <img
        src={imagen}
        className="card-img-top"
        alt={`Portada de ${nombre}`}
        onError={(e) => {
          e.currentTarget.src = "img/sin-imagen.svg"; // imagen por defecto si la URL falla
        }}
      />
      <div className="card-body d-flex flex-column">
        <span className="badge bg-secondary align-self-start mb-2">{categoria}</span>
        <h3 className="card-title h5">{nombre}</h3>
        <p className="card-text flex-grow-1">{descripcion}</p>
        <p className="precio mb-3">{formatearPrecio(precio)}</p>
        <div className="d-flex gap-2">
          <button type="button" className="btn btn-primary flex-grow-1">
            Comprar
          </button>
          <button type="button" className="btn btn-outline-danger" onClick={confirmarEliminar}>
            Eliminar
          </button>
        </div>
      </div>
    </article>
  );
}

export default TarjetaVideojuego;
