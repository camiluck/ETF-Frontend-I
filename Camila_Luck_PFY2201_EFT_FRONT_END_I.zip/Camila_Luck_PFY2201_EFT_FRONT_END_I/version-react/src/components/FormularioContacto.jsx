import { useState } from "react";
import { validarEmail, validarMensaje, validarNombre } from "../utils/validaciones.js";

const VALORES_INICIALES = { nombre: "", email: "", mensaje: "" };

// Formulario de contacto con validación antes del envío.
// Usa su propio state para los valores, los errores y el mensaje de éxito.
function FormularioContacto() {
  const [valores, setValores] = useState(VALORES_INICIALES);
  const [errores, setErrores] = useState({});
  const [enviado, setEnviado] = useState("");

  const manejarCambio = (e) => {
    const { name, value } = e.target;
    setValores({ ...valores, [name]: value });
  };

  const manejarEnvio = (e) => {
    e.preventDefault(); // evita recargar la página

    const nuevosErrores = {
      nombre: validarNombre(valores.nombre),
      email: validarEmail(valores.email),
      mensaje: validarMensaje(valores.mensaje),
    };
    setErrores(nuevosErrores);

    const esValido = Object.values(nuevosErrores).every((mensaje) => mensaje === "");
    if (esValido) {
      setEnviado(`¡Gracias, ${valores.nombre.trim()}! Tu mensaje fue enviado correctamente.`);
      setValores(VALORES_INICIALES);
    } else {
      setEnviado("");
    }
  };

  const clase = (campo) => `form-control ${errores[campo] ? "is-invalid" : ""}`;

  return (
    <>
      <form onSubmit={manejarEnvio} noValidate>
        <div className="mb-3">
          <label htmlFor="nombre" className="form-label">Nombre</label>
          <input id="nombre" name="nombre" className={clase("nombre")} placeholder="Tu nombre" value={valores.nombre} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.nombre}</div>
        </div>

        <div className="mb-3">
          <label htmlFor="email" className="form-label">Email</label>
          <input id="email" name="email" type="email" className={clase("email")} placeholder="nombre@correo.com" value={valores.email} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.email}</div>
        </div>

        <div className="mb-3">
          <label htmlFor="mensaje" className="form-label">Mensaje</label>
          <textarea id="mensaje" name="mensaje" rows="4" className={clase("mensaje")} placeholder="Escribe tu mensaje" value={valores.mensaje} onChange={manejarCambio} />
          <div className="invalid-feedback">{errores.mensaje}</div>
        </div>

        <button type="submit" className="btn btn-primary w-100">Enviar mensaje</button>
      </form>

      {enviado && <div className="alert alert-success mt-3" role="alert">{enviado}</div>}
    </>
  );
}

export default FormularioContacto;
