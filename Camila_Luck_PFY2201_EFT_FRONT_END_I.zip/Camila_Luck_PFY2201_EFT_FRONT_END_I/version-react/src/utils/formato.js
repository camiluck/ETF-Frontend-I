// Formatea un número como precio en pesos chilenos: 39990 -> $39.990
export function formatearPrecio(valor) {
  return Number(valor).toLocaleString("es-CL", { style: "currency", currency: "CLP" });
}
