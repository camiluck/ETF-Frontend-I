// Funciones de validación reutilizables.
// Cada función retorna un mensaje de error, o "" si el valor es válido.

export function validarNombre(valor) {
  const texto = valor.trim();
  if (texto === "") return "El nombre es obligatorio.";
  if (texto.length < 3) return "El nombre debe tener al menos 3 caracteres.";
  if (!/^[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ\s]+$/.test(texto)) return "El nombre solo puede contener letras.";
  return "";
}

export function validarEmail(valor) {
  const texto = valor.trim();
  if (texto === "") return "El email es obligatorio.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(texto)) return "Ingresa un email válido (ej: nombre@correo.com).";
  return "";
}

export function validarMensaje(valor) {
  const texto = valor.trim();
  if (texto === "") return "El mensaje es obligatorio.";
  if (texto.length < 10) return "El mensaje debe tener al menos 10 caracteres.";
  return "";
}

export function validarRequerido(valor, campo) {
  return valor.trim() === "" ? `${campo} es obligatorio.` : "";
}

export function validarPrecio(valor) {
  if (String(valor).trim() === "") return "El precio es obligatorio.";
  const numero = Number(valor);
  if (!Number.isInteger(numero) || numero <= 0) return "El precio debe ser un número entero mayor a 0.";
  return "";
}
