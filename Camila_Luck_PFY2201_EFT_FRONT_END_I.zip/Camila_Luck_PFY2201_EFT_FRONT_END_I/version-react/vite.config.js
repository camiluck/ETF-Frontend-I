import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// base "./" permite abrir el build desde cualquier carpeta (o GitHub Pages)
export default defineConfig({
  plugins: [react()],
  base: "./",
});
