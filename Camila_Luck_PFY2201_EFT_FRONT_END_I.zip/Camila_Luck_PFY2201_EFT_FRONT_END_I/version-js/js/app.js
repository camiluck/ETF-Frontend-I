// =====================================================================
// GameZone - Lógica de la página (JavaScript puro + manipulación del DOM)
// El objeto "tienda" con los videojuegos viene del archivo datos.js
// =====================================================================

// ----- Referencias a elementos del DOM -----
const contenedorJuegos = document.getElementById("listaVideojuegos");
const contenedorFiltros = document.getElementById("filtros");
const contador = document.getElementById("contador");
const formulario = document.getElementById("formContacto");
const mensajeExito = document.getElementById("mensajeExito");

// Categoría seleccionada actualmente
let categoriaActual = "Todas";

// ----- Utilidades -----

// Formatea un número como precio en pesos chilenos: 39990 -> $39.990
function formatearPrecio(valor) {
  return valor.toLocaleString("es-CL", { style: "currency", currency: "CLP" });
}

// Obtiene la lista de categorías sin repetir a partir del objeto
function obtenerCategorias() {
  const categorias = tienda.videojuegos.map((juego) => juego.categoria);
  return ["Todas", ...new Set(categorias)];
}

// ----- Generación dinámica de tarjetas -----

// Crea la tarjeta (elemento <article>) de un videojuego
function crearTarjeta(juego) {
  const tarjeta = document.createElement("article");
  tarjeta.className = "card tarjeta-juego shadow-sm";

  tarjeta.innerHTML = `
    <img src="${juego.imagen}" class="card-img-top" alt="Portada de ${juego.nombre}">
    <div class="card-body d-flex flex-column">
      <span class="badge bg-secondary align-self-start mb-2">${juego.categoria}</span>
      <h3 class="card-title h5">${juego.nombre}</h3>
      <p class="card-text flex-grow-1">${juego.descripcion}</p>
      <p class="precio mb-2">${formatearPrecio(juego.precio)}</p>
      <button class="btn btn-outline-primary btn-comprar">Agregar al carrito</button>
    </div>
  `;

  // Evento del botón: muestra una confirmación simple
  tarjeta.querySelector(".btn-comprar").addEventListener("click", () => {
    alert(`"${juego.nombre}" fue agregado al carrito.`);
  });

  return tarjeta;
}

// Recorre el objeto y muestra solo los videojuegos de la categoría elegida
function mostrarVideojuegos(categoria) {
  contenedorJuegos.innerHTML = ""; // limpia las tarjetas anteriores

  const filtrados =
    categoria === "Todas"
      ? tienda.videojuegos
      : tienda.videojuegos.filter((juego) => juego.categoria === categoria);

  filtrados.forEach((juego) => {
    contenedorJuegos.appendChild(crearTarjeta(juego));
  });

  contador.textContent = `Mostrando ${filtrados.length} de ${tienda.videojuegos.length} videojuegos`;
}

// ----- Filtros por categoría -----

// Crea un botón por cada categoría
function crearFiltros() {
  obtenerCategorias().forEach((categoria) => {
    const boton = document.createElement("button");
    boton.type = "button";
    boton.textContent = categoria;
    boton.className = "btn btn-outline-dark";
    boton.dataset.categoria = categoria;

    boton.addEventListener("click", () => {
      categoriaActual = categoria;
      actualizarBotonActivo();
      mostrarVideojuegos(categoriaActual);
    });

    contenedorFiltros.appendChild(boton);
  });

  actualizarBotonActivo();
}

// Marca visualmente el botón de la categoría seleccionada
function actualizarBotonActivo() {
  contenedorFiltros.querySelectorAll("button").forEach((boton) => {
    const activo = boton.dataset.categoria === categoriaActual;
    boton.classList.toggle("btn-dark", activo);
    boton.classList.toggle("btn-outline-dark", !activo);
    boton.setAttribute("aria-pressed", activo);
  });
}

// ----- Validación del formulario de contacto -----

// Muestra u oculta el error de un campo usando las clases de Bootstrap
function marcarCampo(input, mensajeError) {
  const error = document.getElementById("error" + input.id.charAt(0).toUpperCase() + input.id.slice(1));

  if (mensajeError) {
    input.classList.add("is-invalid");
    input.classList.remove("is-valid");
    error.textContent = mensajeError;
    return false;
  }

  input.classList.remove("is-invalid");
  input.classList.add("is-valid");
  error.textContent = "";
  return true;
}

function validarNombre(valor) {
  if (valor === "") {
    return "El nombre es obligatorio.";
  }
  if (valor.length < 3) {
    return "El nombre debe tener al menos 3 caracteres.";
  }
  return "";
}

function validarEmail(valor) {
  if (valor === "") {
    return "El email es obligatorio.";
  }
  if (!valor.includes("@") || !valor.includes(".")) {
    return "Ingresa un email válido (ej: nombre@correo.com).";
  }
  return "";
}

function validarMensaje(valor) {
  if (valor === "") {
    return "El mensaje es obligatorio.";
  }
  if (valor.length < 10) {
    return "El mensaje debe tener al menos 10 caracteres.";
  }
  return "";
}

formulario.addEventListener("submit", (evento) => {
  evento.preventDefault(); // evita que la página se recargue

  const nombre = document.getElementById("nombre");
  const email = document.getElementById("email");
  const mensaje = document.getElementById("mensaje");

  const nombreOk = marcarCampo(nombre, validarNombre(nombre.value.trim()));
  const emailOk = marcarCampo(email, validarEmail(email.value.trim()));
  const mensajeOk = marcarCampo(mensaje, validarMensaje(mensaje.value.trim()));

  if (nombreOk && emailOk && mensajeOk) {
    mensajeExito.textContent = `¡Gracias, ${nombre.value.trim()}! Tu mensaje fue enviado correctamente.`;
    mensajeExito.classList.remove("d-none");
    formulario.reset();
    [nombre, email, mensaje].forEach((campo) => campo.classList.remove("is-valid"));
  } else {
    mensajeExito.classList.add("d-none");
  }
});

// ----- Menú en celulares: se cierra al tocar un enlace -----
document.querySelectorAll("#menuPrincipal .nav-link").forEach((enlace) => {
  enlace.addEventListener("click", () => {
    const menu = document.getElementById("menuPrincipal");
    if (menu.classList.contains("show")) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });
});

// ----- Inicio -----
crearFiltros();
mostrarVideojuegos(categoriaActual);
