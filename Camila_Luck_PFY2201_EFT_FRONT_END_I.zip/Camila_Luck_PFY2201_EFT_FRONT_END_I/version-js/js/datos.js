// Objeto con la información de los videojuegos disponibles en la tienda.
// Cada videojuego tiene: id, nombre, categoria, precio, descripcion e imagen.
const tienda = {
  nombre: "GameZone",
  videojuegos: [
    {
      "id": 1,
      "nombre": "Neon Strike",
      "categoria": "Acción",
      "precio": 39990,
      "descripcion": "Shooter futurista de ritmo rápido en una ciudad cubierta de neón.",
      "imagen": "img/neon-strike.svg"
    },
    {
      "id": 2,
      "nombre": "Reino de Cenizas",
      "categoria": "RPG",
      "precio": 49990,
      "descripcion": "Aventura épica de rol con mundo abierto, magia y decisiones que importan.",
      "imagen": "img/reino-de-cenizas.svg"
    },
    {
      "id": 3,
      "nombre": "Gol Total 26",
      "categoria": "Deportes",
      "precio": 44990,
      "descripcion": "Simulador de fútbol con ligas, torneos y modo carrera online.",
      "imagen": "img/gol-total-26.svg"
    },
    {
      "id": 4,
      "nombre": "Turbo Andes",
      "categoria": "Carreras",
      "precio": 29990,
      "descripcion": "Carreras a toda velocidad por caminos de montaña y desiertos del norte.",
      "imagen": "img/turbo-andes.svg"
    },
    {
      "id": 5,
      "nombre": "Imperio Estelar",
      "categoria": "Estrategia",
      "precio": 34990,
      "descripcion": "Construye tu flota, coloniza planetas y conquista la galaxia por turnos.",
      "imagen": "img/imperio-estelar.svg"
    },
    {
      "id": 6,
      "nombre": "Isla Perdida",
      "categoria": "Aventura",
      "precio": 24990,
      "descripcion": "Explora una isla misteriosa, resuelve acertijos y descubre sus secretos.",
      "imagen": "img/isla-perdida.svg"
    },
    {
      "id": 7,
      "nombre": "Sombra Ninja",
      "categoria": "Acción",
      "precio": 19990,
      "descripcion": "Plataformas y sigilo: infíltrate en fortalezas sin ser descubierto.",
      "imagen": "img/sombra-ninja.svg"
    },
    {
      "id": 8,
      "nombre": "Crónicas del Dragón",
      "categoria": "RPG",
      "precio": 54990,
      "descripcion": "Forma tu grupo de héroes y enfrenta dragones en combates tácticos.",
      "imagen": "img/cronicas-del-dragon.svg"
    },
    {
      "id": 9,
      "nombre": "Básquet Pro",
      "categoria": "Deportes",
      "precio": 32990,
      "descripcion": "Partidos 5 contra 5, modo callejero y competencias de clavadas.",
      "imagen": "img/basquet-pro.svg"
    }
  ]
};
